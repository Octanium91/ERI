To launch Easy Recovery Installer start "ERI_client.exe".

https://sites.google.com/view/eriua